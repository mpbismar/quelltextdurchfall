
public class Celsius extends Conversion{

	public double convert(double value)
	{
		return ( (1.8 * value) + 32.0);
	}
}
