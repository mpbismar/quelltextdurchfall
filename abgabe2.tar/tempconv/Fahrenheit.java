
public class Fahrenheit extends Conversion {

	public double convert(double value)
	{
		return ( (value - 32.0) * ((5.0)/(9.0)) );
	}
}
