
abstract public class Conversion {

	abstract double convert(double value);

}