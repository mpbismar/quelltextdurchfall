#include "arena.h"
unsigned char arena[BLOCKSIZE*NUM_BLOCKS]; 
unsigned short allocated_map[NUM_BLOCKS/16];
