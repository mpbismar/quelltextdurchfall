/* allocate.h */

# ifndef __allocate_h
# define __allocate_h

void* allocate();
void deallocate(void *data);
void print_all_map();

# endif
