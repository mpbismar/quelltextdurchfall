/* bithandler.h */


void set_bit(unsigned short* shorty, int pos);
void unset_bit(unsigned short* shorty, int pos);
unsigned char check_bit(unsigned short* shorty, int pos);
void print_bitmap(unsigned short* handay);